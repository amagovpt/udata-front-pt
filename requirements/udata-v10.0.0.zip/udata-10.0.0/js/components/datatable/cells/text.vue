<template><span>{{value}}</span></template>

<script>
export default {
    name: 'datatable-cell-text'
};
</script>
