__author__ = "rohe0002"
__all__ = ["adfs_v1x", "adfs_v20", "basic", "saml_uri", "shibboleth_uri"]
