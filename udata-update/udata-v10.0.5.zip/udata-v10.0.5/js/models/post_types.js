export var post_types = [{"id": "html", "label": "HTML"}, {"id": "markdown", "label": "Markdown"}];
export default post_types
