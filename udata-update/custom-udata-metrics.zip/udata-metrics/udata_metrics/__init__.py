'''
udata-metrics

Connexion handler to metrics service for udata
'''


__version__ = '2.0.5.dev'
__description__ = 'Connexion handler to metrics service for udata'


def init_app(app):
    # Do whatever you want to initialize your plugin
    pass
