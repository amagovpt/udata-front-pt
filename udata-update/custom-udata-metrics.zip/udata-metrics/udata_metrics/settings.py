'''
Default settings for udata-metrics
'''

# Metrics PostgREST API
METRICS_API = None
